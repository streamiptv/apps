Thanks for using the Ultimate XC Panel!

Here are some things you may find useful to know regarding using the panel.

You can alter some configurations of the panel such as:-
 - Enable/Disable Dashboard
 - Edit Dashboard Articles
 - Enable/Disable Branding Removal
 - Enable/Disable User profile editing
 - Edit Default profile

All of the above can be done by editing the 'config.php' file located at: UltimateXC/assets/includes/

How to change Dashboard message(s): Navigate to: UltimateXC/message/ here you will find two .json files named article 1 & 2. Simply edit one or both of these where the text is between quotation marks, you must ensure you keep the existing layout structure.

When using this panel to control an XCIPTV/ORPlayer application using the LicV4 API Scheme you need to ensure that the Appname (/res/Strings.xml) and the CustomerID match the application you are connecting with.

