<?php 
print "<head><meta name=\"viewport\" content=\"video/mp4\"></head>\n";
print "<body><video controls=\"\" autoplay=\"\" name=\"media\"><source src=\"../intro.mp4\" type=\"video/mp4\"></video></body>";

