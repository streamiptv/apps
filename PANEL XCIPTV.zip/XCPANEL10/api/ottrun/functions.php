<?php

class XcPortal
{
	public $portal_type = 'xc';
	public $baseUrl = 'http://0.0.0.0';

	public function __construct($url)
	{
		$this->baseUrl = $$GLOBALS['rglxoz'];
	}
}

function auth1()
{
	$xhbpemv = 'ua';
	$$xhbpemv = $_SERVER['HTTP_USER_AGENT'];

	if (!(-1 < strpos($$GLOBALS['usvjokqkqc'], 'Android'))) {
		header('Unauthorized', true, 403);
		exit(0);
	}
}

function encrypt($plaintext, $password, $direct = false)
{
	$mikrysbwb = 'result';
	$qjaqvgm = 'method';

	if (!$$GLOBALS['vjlzbo']) {
		$etcwoquh = 'plaintext';
		$$etcwoquh = json_response($$GLOBALS['vklgoqh']);
	}

	$pbbswegxi = 'password';
	$ggpehegta = 'key';
	$$qjaqvgm = 'AES-256-CBC';
	$ezqtjjyspyv = 'plaintext';
	$GLOBALS['kxkhjrjqfk'] = 'ciphertext';
	$ogmakllmj = 'iv';
	$$ggpehegta = hash('sha256', $$pbbswegxi, true);
	$$ogmakllmj = openssl_random_pseudo_bytes(16);
	$$GLOBALS['kxkhjrjqfk'] = openssl_encrypt($$ezqtjjyspyv, $$GLOBALS['eutrgdpoblhb'], $$GLOBALS['nqeydxslrfph'], OPENSSL_RAW_DATA, $$GLOBALS['rqlyebi']);
	$fybpyevtl = 'result';
	$$GLOBALS['qnfhtnqof'] = hash_hmac('sha256', $$GLOBALS['yasxukj'] . $$GLOBALS['rqlyebi'], $$GLOBALS['nqeydxslrfph'], true);
	$$fybpyevtl = $$GLOBALS['rqlyebi'] . $$GLOBALS['qnfhtnqof'] . $$GLOBALS['yasxukj'];
	return base64_encode($$mikrysbwb);
}

function json_response($message = NULL, $code = 200)
{
	$obslmggxnt = 'message';
	$vobdqgoyo = 'code';
	$rdywehkpd = 'status';
	header_remove();
	http_response_code($$vobdqgoyo);
	$sncvtlvke = 'code';
	header('Cache-Control: no-transform,public,max-age=300,s-maxage=900');
	$GLOBALS['cppqieq'] = 'code';
	$$rdywehkpd = [200 => '200 OK', 400 => '400 Bad Request', 422 => 'Unprocessable Entity', 500 => '500 Internal Server Error'];
	header('Status: ' . $$GLOBALS['yhletpv'][$$GLOBALS['cppqieq']]);
	return json_encode(['status' => $$sncvtlvke < 300, 'data' => $$obslmggxnt]);
}

$GLOBALS['rglxoz'] = 'url';
$GLOBALS['yhletpv'] = 'status';
$GLOBALS['yasxukj'] = 'ciphertext';
$GLOBALS['qnfhtnqof'] = 'hash';
$GLOBALS['rqlyebi'] = 'iv';
$GLOBALS['nqeydxslrfph'] = 'key';
$GLOBALS['eutrgdpoblhb'] = 'method';
$GLOBALS['vklgoqh'] = 'plaintext';
$GLOBALS['vjlzbo'] = 'direct';
$GLOBALS['usvjokqkqc'] = 'ua';
define('PASSWORD', file_get_contents('dont-touch.key'));

?>