<?php

include 'functions.php';
error_reporting(0);
auth1();
$dnsList = [];
$pkg = (isset($_REQUEST['pkg']) ? $_REQUEST['pkg'] : NULL);

if ($pkg === 'com.ottrun.orvpn') {
	array_push($dnsList, new XcPortal((isset($_SERVER['HTTPS']) && ($_SERVER['HTTPS'] !== 'off') ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']) . '/'));
}

echo encrypt($dnsList, PASSWORD);

?>