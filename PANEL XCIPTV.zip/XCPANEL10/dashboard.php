<?php

session_start();
include 'assets/includes/db.php';
include 'assets/includes/config.php';

if ($_ERRORS) {
	error_reporting(E_ALL);
	ini_set('display_errors', 1);
}
if (!isset($_SESSION['loggedin']) && !$_SESSION['loggedin']) {
	header('location: logout.php');
}

echo '<!doctype html>' . "\r\n" . '<html lang="en">' . "\r\n\r\n" . '<head>' . "\r\n\r\n" . '    ';
include 'assets/includes/title-meta.php';
echo "\r\n" . '    ';
include 'assets/includes/head-css.php';
echo "\r\n" . '</head>' . "\r\n\r\n" . '<body data-sidebar="dark">' . "\r\n\r\n" . '    <!-- Loader -->' . "\r\n" . '    <div id="preloader">' . "\r\n" . '        <div id="status">' . "\r\n" . '            <div class="spinner">' . "\r\n" . '                <i class="ri-loader-line spin-icon"></i>' . "\r\n" . '            </div>' . "\r\n" . '        </div>' . "\r\n" . '    </div>' . "\r\n\r\n" . '    <div id="layout-wrapper">' . "\r\n\r\n" . '        ';
include 'assets/includes/topbar.php';
echo "\r\n" . '        ';
include 'assets/includes/sidebar.php';
echo "\r\n" . '        <div class="main-content">' . "\r\n\r\n" . '            <div class="page-content">' . "\r\n" . '                <div class="container-fluid">' . "\r\n\r\n" . '                    <div class="row">' . "\r\n" . '                        <div class="col-12">' . "\r\n" . '                            <div class="page-title-box d-flex align-items-center justify-content-between">' . "\r\n" . '                                <h4 class="mb-0">Multipurpose Panel</h4>' . "\r\n\r\n" . '                                <div class="page-title-right">' . "\r\n" . '                                    <ol class="breadcrumb m-0">' . "\r\n" . '                                        <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>' . "\r\n" . '                                        <li class="breadcrumb-item active">News</li>' . "\r\n" . '                                    </ol>' . "\r\n" . '                                </div>' . "\r\n\r\n" . '                            </div>' . "\r\n" . '                        </div>' . "\r\n" . '                    </div>' . "\r\n\r\n" . '                    ';

if ($_VERSION !== $VERSION_JSON['version']) {
	echo '' . $_UPDATE_MESSAGE;
}

echo "\r\n" . '                    <div class="row">' . "\r\n" . '                        <div class="col-10 mx-auto">' . "\r\n" . '                            <div class="card">' . "\r\n" . '                                <div class="card-body">' . "\r\n" . '                                    <div class="media mb-4">' . "\r\n" . '                                        <img class="d-flex mr-3 rounded-circle avatar-sm" src="';
echo $ARTICLE_1_JSON['author_avatar'];
echo '" alt="Avatar image">' . "\r\n" . '                                        <div class="media-body">' . "\r\n" . '                                            <h5 class="font-size-14 my-1">';
echo $ARTICLE_1_JSON['author_name'] . ' (' . $ARTICLE_1_JSON['author_role'] . ')';
echo '</h5>' . "\r\n" . '                                            <small class="text-muted"><a href="';
echo $ARTICLE_1_JSON['author_telegram_url'];
echo '" target="_blank">';
echo $ARTICLE_1_JSON['author_telegram'];
echo '</a></small>' . "\r\n" . '                                        </div>' . "\r\n" . '                                    </div>' . "\r\n\r\n" . '                                    <h4 class="mt-0 font-size-16">';
echo $ARTICLE_1_JSON['article_title'];
echo ' <span class="badge badge-';
echo $ARTICLE_1_JSON['article_badge'];
echo '">';
echo $ARTICLE_1_JSON['article_type'];
echo '</span></h4>' . "\r\n\r\n" . '                                    ';
echo $ARTICLE_1_JSON['article_header'] . $profile_data['profile_name'] . ', </p>';
echo '                                    ';
echo $ARTICLE_1_JSON['article_body'];
echo '                                    ';
echo $ARTICLE_1_JSON['article_footer'];
echo '                                </div>' . "\r\n" . '                            </div>' . "\r\n" . '                        </div>' . "\r\n" . '                    </div>' . "\r\n\r\n" . '                    <div class="row">' . "\r\n" . '                        <div class="col-10 mx-auto">' . "\r\n" . '                            <div class="card">' . "\r\n" . '                                <div class="card-body">' . "\r\n" . '                                    <div class="media mb-4">' . "\r\n" . '                                        <img class="d-flex mr-3 rounded-circle avatar-sm" src="';
echo $ARTICLE_2_JSON['author_avatar'];
echo '" alt="Avatar image">' . "\r\n" . '                                        <div class="media-body">' . "\r\n" . '                                            <h5 class="font-size-14 my-1">';
echo $ARTICLE_2_JSON['author_name'] . ' (' . $ARTICLE_2_JSON['author_role'] . ')';
echo '</h5>' . "\r\n" . '                                            <small class="text-muted"><a href="';
echo $ARTICLE_2_JSON['author_telegram_url'];
echo '" target="_blank">';
echo $ARTICLE_2_JSON['author_telegram'];
echo '</a></small>' . "\r\n" . '                                        </div>' . "\r\n" . '                                    </div>' . "\r\n\r\n" . '                                    <h4 class="mt-0 font-size-16">';
echo $ARTICLE_2_JSON['article_title'];
echo ' <span class="badge badge-';
echo $ARTICLE_2_JSON['article_badge'];
echo '">';
echo $ARTICLE_2_JSON['article_type'];
echo '</span></h4>' . "\r\n\r\n" . '                                    ';
echo $ARTICLE_2_JSON['article_header'] . $profile_data['profile_name'] . ', </p>';
echo '                                    ';
echo $ARTICLE_2_JSON['article_body'];
echo '                                    ';
echo $ARTICLE_2_JSON['article_footer'];
echo '                                </div>' . "\r\n" . '                            </div>' . "\r\n" . '                        </div>' . "\r\n" . '                    </div>' . "\r\n\r\n" . '                </div>' . "\r\n" . '            </div>' . "\r\n\r\n" . '            ';
include 'assets/includes/footer.php';
echo "\r\n" . '        </div>' . "\r\n" . '    </div>' . "\r\n\r\n" . '    ';
include 'assets/includes/right-sidebar.php';
echo "\r\n" . '    ';
include 'assets/includes/vendor-scripts.php';
echo "\r\n" . '    <script src="./assets/js/app.js"></script>' . "\r\n\r\n" . '</body>' . "\r\n\r\n" . '</html>';

?>