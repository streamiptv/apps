<?php

include 'assets/includes/config.php';
echo '<footer class="footer">' . "\r\n" . '    <div class="container-fluid">' . "\r\n" . '        <div class="row">' . "\r\n\r\n" . '            ';

if ($MasterAPP_BRANDING) {
	echo '            <div class="col-sm-6">' . "\r\n" . '                <script>document.write(new Date().getFullYear())</script> © EQUIP Media' . "\r\n" . '            </div>' . "\r\n" . '            ' . "\r\n" . '                </div>' . "\r\n" . '            </div>' . "\r\n" . '            ';
}

echo '        </div>' . "\r\n" . '    </div>' . "\r\n" . '</footer>';

?>