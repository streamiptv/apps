<?php

echo '<div class="vertical-menu">' . "\r\n\r\n" . '    <div data-simplebar class="h-100">' . "\r\n\r\n" . '        <div id="sidebar-menu">' . "\r\n\r\n" . '            <ul class="metismenu list-unstyled" id="side-menu">' . "\r\n" . '                <li class="menu-title">XC Menu</li>' . "\r\n" . '                ';

if ($DASHBOARD) {
	echo '<li>' . "\r\n" . '                            <a href="dashboard.php" class="waves-effect">' . "\r\n" . '                                <i class="ri-dashboard-line"></i>' . "\r\n" . '                                <span>Dashboard</span>' . "\r\n" . '                            </a>' . "\r\n" . '                        </li>';
}

echo "\r\n" . '                <li class="menu-title">Streaming Applications</li>' . "\r\n\r\n" . '                <li class="mm-active">' . "\r\n" . '                    <a href="javascript: void(0);" class="has-arrow waves-effect" aria-expanded="true">' . "\r\n" . '                        <i class="ri-tv-line"></i>' . "\r\n" . '                        <span>OTTRun XCIPTV</span>' . "\r\n" . '                    </a>' . "\r\n\r\n" . '                    <ul class="sub-menu" aria-expanded="true">' . "\r\n" . '                        <li><a href="javascript: void(0);" class="has-arrow"><i class="ri-home-gear-line"></i>Configuration</a>' . "\r\n" . '                            <ul class="sub-menu" aria-expanded="true">' . "\r\n" . '                                <li><a href="ottrunxciptv_licset.php"><i class="ri-key-line"></i>Licence</a></li>' . "\r\n" . '                                <li><a href="ottrunxciptv_application.php"><i class="ri-smartphone-line"></i>Application</a></li>' . "\r\n" . '                                <li><a href="ottrunxciptv_customization.php"><i class="ri-palette-line"></i>Customization</a></li>' . "\r\n" . '                            </ul>' . "\r\n" . '                        </li>' . "\r\n" . '                        <li>' . "\r\n" . '                            <a href="ottrunvpn_ovpn.php">' . "\r\n" . '                                <span><i class="ri-shield-cross-line"></i>OpenVPN Config <i class="ri-external-link-line"></i></span>' . "\r\n" . '                            </a>' . "\r\n\r\n" . '                        </li>' . "\r\n" . '                        <li>' . "\r\n" . '                            <a href="ottrunxciptv_messages.php">' . "\r\n" . '                                <span><i class="ri-chat-upload-line"></i>Messages & Announcements</span>' . "\r\n" . '                            </a>' . "\r\n" . '                        </li>' . "\r\n" . '                        <li>' . "\r\n" . '                            <a href="ottrunxciptv_update.php">' . "\r\n" . '                                <span><i class="ri-upload-cloud-line"></i>Remote Update</span>' . "\r\n" . '                            </a>' . "\r\n" . '                        </li>' . "\r\n" . '                        <li>' . "\r\n" . '                            <a href="ottrunxciptv_monetization.php">' . "\r\n" . '                                <span><i class="ri-advertisement-line"></i>Ad Monetization</span>' . "\r\n" . '                            </a>' . "\r\n" . '                        </li>' . "\r\n" . '                        <li>' . "\r\n" . '                            <a href="ottrunxciptv_connections.php">' . "\r\n" . '                                <span><i class="ri-device-line"></i>Connections</span>' . "\r\n" . '                            </a>' . "\r\n" . '                        </li>' . "\r\n" . '                        <!-- <li>' . "\r\n" . '                            <a href="#">' . "\r\n" . '                                <span><i class="ri-install-line"></i><s>Command Center</s></span>' . "\r\n" . '                            </a>' . "\r\n" . '                        </li> -->' . "\r\n" . '                    </ul>' . "\r\n" . '                </li>' . "\r\n\r\n" . '                <li class="menu-title">Virtual Private Networks</li>' . "\r\n\r\n" . '                <li>' . "\r\n" . '                    <a href="javascript: void(0);" class="has-arrow waves-effect">' . "\r\n" . '                        <i class="ri-shield-keyhole-line"></i>' . "\r\n" . '                        <span>OTTRun VPN</span>' . "\r\n" . '                    </a>' . "\r\n\r\n" . '                    <ul class="sub-menu" aria-expanded="true">' . "\r\n" . '                        <li>' . "\r\n" . '                            <a href="ottrunvpn_domains.php">' . "\r\n" . '                                <span><i class="ri-global-line"></i>Domain List</span>' . "\r\n" . '                            </a>' . "\r\n" . '                        </li>' . "\r\n" . '                        <li>' . "\r\n" . '                            <a href="ottrunvpn_ovpn.php">' . "\r\n" . '                                ';
$active_count = 0;
$sql = 'SELECT * FROM ovpn_config';
$result = $sqlite3->query($sql);

while ($row = $result->fetchArray()) {
	if ($row['vpn_status'] == 'ACTIVE') {
		$active_count++;
	}
}

echo '                                <span class="badge badge-pill badge-primary float-right">';
echo $active_count;
echo '</span>' . "\r\n" . '                                <i class="ri-shield-cross-line"></i>OpenVPN Config</a>' . "\r\n" . '                        </li>' . "\r\n" . '                        <li>' . "\r\n" . '                            <a href="ottrunvpn_customers.php">' . "\r\n" . '                                ';
$active_count = 0;
$disabled_count = 0;
$expired_count = 0;
$sql = 'SELECT * FROM extra_customers_ottrun';
$result = $sqlite3->query($sql);

while ($row = $result->fetchArray()) {
	if ($expired = strtotime($row['expiry']) < time()) {
		$expired_count++;
		continue;
	}

	if ($row['status'] == 'Disabled') {
		$disabled_count++;
		continue;
	}

	if ($row['status'] == 'Active') {
		$active_count++;
	}
}

echo '                                ';

if (0 < $disabled_count) {
	echo '<span class="badge badge-pill badge-danger float-right">';
	echo $disabled_count;
	echo '</span>';
}

echo '                                ';

if (0 < $expired_count) {
	echo '<span class="badge badge-pill badge-warning float-right">';
	echo $expired_count;
	echo '</span>';
}

echo '                                ';

if (0 < $active_count) {
	echo '<span class="badge badge-pill badge-success float-right">';
	echo $active_count;
	echo '</span>';
}

echo '                                <i class="ri-user-add-line"></i>Extra Customers</a>' . "\r\n" . '                        </li>' . "\r\n" . '                    </ul>' . "\r\n" . '                </li>' . "\r\n\r\n" . '                <li class="menu-title">Custom WebViews</li>' . "\r\n\r\n" . '                <li>' . "\r\n" . '                    <a href="webviews_tvsportsguide.php" class="waves-effect">' . "\r\n" . '                        <i class="ri-football-line"></i>' . "\r\n" . '                        <span>TV Sports Guide</span>' . "\r\n" . '                    </a>' . "\r\n" . '                </li>' . "\r\n\r\n" . '            </ul>' . "\r\n" . '        </div>' . "\r\n" . '    </div>' . "\r\n" . '</div>';

?>